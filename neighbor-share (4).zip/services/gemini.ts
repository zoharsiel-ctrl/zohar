
import { GoogleGenAI, Type } from "@google/genai";
import { Item, ItemCategory } from "../types";

// Helper to get AI instance with latest key
const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getSmartItemAnalysis = async (itemName: string) => {
  try {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Analyze this item for a neighbor-to-neighbor sharing platform: "${itemName}".
      Return a clean JSON object with:
      1. "description": A short, catchy marketing description in Hebrew.
      2. "price": A recommended daily rental price in NIS (number only).
      3. "category": One of these: כלי עבודה, גינון, מטבח, אלקטרוניקה, ניקיון, קמפינג, אחר.
      4. "faqs": An array of 2-3 common questions and answers about this specific item in Hebrew.
      Example structure: {"description": "...", "price": 40, "category": "...", "faqs": [{"question": "...", "answer": "..."}]}`,
      config: {
        maxOutputTokens: 500,
        temperature: 0.7,
        responseMimeType: "application/json"
      }
    });
    // Accessing .text property as per guidelines
    return response.text || "";
  } catch (error) {
    console.error("AI Analysis Error:", error);
    return null;
  }
};

export const getSmartSearchResults = async (query: string, items: Item[]) => {
  if (!query || query.length < 3) return null;
  const itemsSimplified = items.map(i => ({ id: i.id, name: i.name, desc: i.description, category: i.category }));
  try {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `The user is looking for: "${query}".
      Based on the user's intent, which of these items are relevant?
      Available Items: ${JSON.stringify(itemsSimplified)}
      Return ONLY a JSON array of the IDs of relevant items. If none are relevant, return [].`,
      config: {
        maxOutputTokens: 200,
        temperature: 0.2,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: { type: Type.STRING }
        }
      }
    });
    // Accessing .text property as per guidelines
    const text = response.text;
    if (text) return JSON.parse(text) as string[];
    return null;
  } catch (error) {
    console.error("AI Search Error:", error);
    return null;
  }
};
