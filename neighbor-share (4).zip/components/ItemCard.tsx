
import React, { useState } from 'react';
import { Item, User } from '../types';
import { MapPin, Shield, Star, Award, Zap, HelpCircle, ChevronDown, ChevronUp, Gift } from 'lucide-react';
import TrustBadge from './TrustBadge';

interface ItemCardProps {
  item: Item;
  owner: User;
  onClick: (item: Item) => void;
}

const ItemCard: React.FC<ItemCardProps> = ({ item, owner, onClick }) => {
  const [showFaqs, setShowFaqs] = useState(false);

  const handleToggleFaqs = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowFaqs(!showFaqs);
  };

  return (
    <div 
      onClick={() => onClick(item)}
      className={`bg-white rounded-[32px] overflow-hidden border border-slate-100 transition-all duration-500 ease-[cubic-bezier(0.34,1.56,0.64,1)] cursor-pointer group shadow-sm hover:shadow-[0_30px_60px_-15px_rgba(16,185,129,0.15)] hover:-translate-y-3 relative flex flex-col ${
        item.isPromoted ? 'ring-2 ring-emerald-500/20' : ''
      }`}
    >
      <div className="relative h-56 overflow-hidden">
        <img 
          src={item.images[0]} 
          alt={item.name} 
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
        />
        
        {/* Overlay for image hover */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        
        {/* Badges */}
        <div className="absolute top-4 right-4 flex flex-col gap-2 items-end z-10">
           {item.isPromoted && (
             <div className="bg-amber-400 text-white text-[10px] font-black px-3 py-1.5 rounded-xl flex items-center gap-1.5 shadow-xl animate-pulse">
               <Zap size={12} fill="currentColor" /> מומלץ
             </div>
           )}
           {item.pricePerDay === 0 && (
            <div className="bg-gradient-to-r from-emerald-600 to-teal-500 text-white text-[11px] font-black px-4 py-2 rounded-2xl uppercase tracking-widest shadow-2xl border border-white/30 backdrop-blur-md flex items-center gap-2 animate-pulse">
              <Gift size={14} className="fill-white/20" /> השאלה בחינם
            </div>
          )}
        </div>
        
        {/* Glassmorphism Owner Info */}
        <div className="absolute bottom-4 left-4 right-4 translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500 z-10">
           <div className="bg-white/90 backdrop-blur-md p-2 rounded-2xl border border-white/50 flex items-center justify-between shadow-lg">
              <div className="flex items-center gap-2">
                <img src={owner.avatar} className="w-8 h-8 rounded-lg object-cover border border-white shadow-sm" />
                <span className="text-[10px] font-black text-slate-800">{owner.name}</span>
              </div>
              <TrustBadge score={owner.trustScore} showText={false} />
           </div>
        </div>
      </div>

      <div className="p-6 text-right flex-1 flex flex-col">
        <div className="flex justify-between items-start mb-2">
          <div className="text-left shrink-0 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-100 group-hover:bg-emerald-50 group-hover:border-emerald-500/20 group-hover:shadow-sm transition-all duration-300">
            <p className="text-emerald-600 font-black text-lg leading-none">
              {item.pricePerDay === 0 ? 'חינם' : `₪${item.pricePerDay}`}
            </p>
            {item.pricePerDay > 0 && <p className="text-[9px] text-slate-400 font-bold uppercase mt-1">ליום</p>}
          </div>
          <div className="flex-1 ml-3 overflow-hidden">
            <h3 className="font-black text-slate-900 text-xl truncate group-hover:text-emerald-700 transition-colors duration-300">{item.name}</h3>
            <div className="flex items-center gap-1 justify-end mt-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{item.category}</span>
            </div>
          </div>
        </div>
        
        <p className="text-slate-500 text-sm font-medium line-clamp-2 mb-4 h-10 leading-relaxed">
          {item.description}
        </p>

        {/* FAQ Toggle Button */}
        {item.faqs && item.faqs.length > 0 && (
          <button 
            onClick={handleToggleFaqs}
            className="flex items-center justify-between w-full p-3 mb-4 bg-slate-50 rounded-2xl border border-slate-100 text-slate-600 hover:bg-emerald-50 hover:border-emerald-200 hover:text-emerald-700 transition-all duration-300 group/faq"
          >
            <div className="flex items-center gap-2">
              <HelpCircle size={16} className="text-slate-400 group-hover/faq:text-emerald-500 transition-colors" />
              <span className="text-[11px] font-bold uppercase tracking-wider">שאלות נפוצות</span>
            </div>
            {showFaqs ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
          </button>
        )}

        {/* Expandable FAQ Section */}
        {showFaqs && item.faqs && (
          <div className="mb-4 space-y-3 animate-in fade-in slide-in-from-top-2 duration-300">
            {item.faqs.map((faq, idx) => (
              <div key={idx} className="bg-emerald-50/50 p-3 rounded-xl border border-emerald-100/50">
                <p className="text-[10px] font-black text-emerald-800 mb-1 leading-tight">Q: {faq.question}</p>
                <p className="text-[10px] font-medium text-slate-600 leading-tight">A: {faq.answer}</p>
              </div>
            ))}
          </div>
        )}

        <div className="mt-auto flex items-center gap-4 pt-4 border-t border-slate-50 text-slate-400 text-xs font-bold">
          <div className="flex items-center gap-1.5 hover:text-emerald-600 transition-colors duration-300">
            <MapPin size={14} />
            <span>0.4 ק"מ</span>
          </div>
          <div className="flex items-center justify-end flex-1 gap-2">
             {item.insuranceCovered && (
               <div className="flex items-center gap-1 px-2 py-0.5 bg-blue-50 rounded-lg text-blue-600 border border-blue-100/50">
                 <Shield size={12} />
                 <span className="text-[9px] uppercase tracking-tighter">מבוטח</span>
               </div>
             )}
             <span className={item.insuranceCovered ? "text-blue-600" : "text-emerald-600"}>זמין כעת</span>
          </div>
        </div>
      </div>
      
      {/* Decorative Hover Line */}
      <div className="absolute bottom-0 left-0 w-full h-1.5 bg-gradient-to-r from-emerald-400 to-teal-500 scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-right" />
    </div>
  );
};

export default ItemCard;
