
import React from 'react';
import { ShieldCheck, ShieldAlert, Star } from 'lucide-react';

interface TrustBadgeProps {
  score: number;
  showText?: boolean;
}

const TrustBadge: React.FC<TrustBadgeProps> = ({ score, showText = true }) => {
  const getBadgeColor = () => {
    if (score >= 90) return 'text-emerald-600 bg-emerald-50 border-emerald-200';
    if (score >= 75) return 'text-amber-600 bg-amber-50 border-amber-200';
    return 'text-rose-600 bg-rose-50 border-rose-200';
  };

  const getLabel = () => {
    if (score >= 90) return 'אמינות גבוהה';
    if (score >= 75) return 'אמין';
    return 'משתמש חדש';
  };

  return (
    <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-xs font-semibold ${getBadgeColor()}`}>
      {score >= 75 ? <ShieldCheck size={14} /> : <ShieldAlert size={14} />}
      {showText && <span>{getLabel()} • {score}%</span>}
      {!showText && <span className="flex items-center gap-0.5"><Star size={10} fill="currentColor"/> {score}</span>}
    </div>
  );
};

export default TrustBadge;
