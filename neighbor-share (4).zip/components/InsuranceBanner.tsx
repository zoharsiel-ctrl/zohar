
import React from 'react';
import { ShieldCheck, Info } from 'lucide-react';

const InsuranceBanner: React.FC = () => {
  return (
    <div className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white rounded-2xl p-6 shadow-lg relative overflow-hidden text-right">
      <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start gap-4">
          <div className="bg-white/20 p-3 rounded-xl backdrop-blur-md">
            <ShieldCheck size={28} className="text-white" />
          </div>
          <div>
            <h4 className="font-bold text-xl mb-1">הגנת NeighborSafe™</h4>
            <p className="text-blue-100 text-sm max-w-md">
              כל השאלה מכוסה בביטוח עד גובה של ₪5,000 לנזק מקרי או אובדן. 
              שתפו בראש שקט בידיעה שהציוד שלכם מוגן.
            </p>
          </div>
        </div>
        <button className="bg-white text-blue-700 px-6 py-2.5 rounded-xl font-bold text-sm hover:bg-blue-50 transition-colors whitespace-nowrap self-start md:self-center">
          למידע נוסף
        </button>
      </div>
      {/* Decorative background circle */}
      <div className="absolute -left-12 -bottom-12 w-48 h-48 bg-white/10 rounded-full blur-3xl"></div>
    </div>
  );
};

export default InsuranceBanner;
